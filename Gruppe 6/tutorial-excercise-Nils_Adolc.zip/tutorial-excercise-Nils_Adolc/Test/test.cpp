
#include<iostream>
#include<adolc/adtl.h>
typedef adtl::adouble adouble;

template<typename T>
T f(T x) {
    return x*x;
}

int main() {
  adouble x, y;
  double seed= 1;
  for(int i = 0; i < 10; i++){
      x=i;
      x.setADValue(&seed);
      y=-f(x);
      std::cout<<"f("<<x.getValue()<<")= "<<y.getValue()<<" ; f'("<<x.getValue()<<")= "<<*y.getADValue()<<std::endl;
  }

  return 0;
}
