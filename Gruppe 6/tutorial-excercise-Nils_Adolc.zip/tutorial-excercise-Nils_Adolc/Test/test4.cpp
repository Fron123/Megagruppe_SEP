
#include<iostream>
#include<adolc/adtl.h>
typedef adtl::adouble adouble;

double seed1 =1;
double seed0 =0;

template<typename T,typename TP>
T f(T x, TP p) {
    return x*x*p;
}

void derivation(adouble& x, adouble& y, adouble& p) {
    x.setADValue(&seed1);
    y=f(x,p);
    x.setADValue(&seed0);
}

//template<typename TT>
void do_something(adouble &x,adouble& p){
    adouble xp=x, y;
    derivation(xp,y,p);
    std::cout<<"f("<<x.getValue()<<")= "<<y.getValue()<<" ; f'("<<x.getValue()<<")= "<<*y.getADValue()<<std::endl;
    x=x-*y.getADValue();
    std::cout<<"x_new= "<<x<<std::endl;
}
void derivation2(adouble& x,adouble& p) {
    p.setADValue(&seed1);
    do_something(x,p);
    p.setADValue(&seed0);

}

int main() {
  adouble x=10;
  adouble p=2;
  //do_something(x,p);
  derivation2(x,p);
  std::cout<<"dx/dp= "<<*x.getADValue()<<std::endl;

  return 0;
}
