
#include<iostream>
#include<adolc/adolc.h>


template<typename T>
T f(T x, int p) {
    return x*x*p;
}
double seed =2;
template<typename T>
void create_tape(T p) {
    adouble x,y;
    double *xp=new double,*yp=new double;
    trace_on(0);
    x<<=*xp;
    x.setValue(seed);
    y=f(x,p);
    y>>=*yp;
    trace_off();
    delete xp;
    delete yp;
}
void do_something(const int s, const int e){
    double *xp=new double,*yp=new double;
    double** der=new double*;
    *der=new double;

    create_tape(2);
    for(int i= s; i < e; i++){
        *xp=i;
        function(0,1,1,xp,yp);
        jacobian(0,1,1,xp,der);
        std::cout<<"f("<<*xp<<")= "<<*yp<<" ; f'("<<*xp<<")= "<<**der<<std::endl;

    }

    delete xp;
    delete yp;
    delete *der;
    delete der;
}

int main() {
  const int s=0;
  const int e =10;
  double *xp=new double,*yp=new double;
  double** der=new double*;
  *der=new double;

  create_tape(2);
  for(int i= s; i < e; i++){
      *xp=i;
      function(0,1,1,xp,yp);
      jacobian(0,1,1,xp,der);
      std::cout<<"f("<<*xp<<")= "<<*yp<<" ; f'("<<*xp<<")= "<<**der<<std::endl;

  }

  delete xp;
  delete yp;
  delete *der;
  delete der;

  return 0;
}
