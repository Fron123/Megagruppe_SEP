
#include<iostream>
#include <Eigen/Dense>
#include<adolc/adtl.h>
#include<adolc/adolc.h>
#include "dco.hpp"
typedef adtl::adouble adouble_t;

const int N = 50;

int main() {
  using DCO_T=typename dco::gt1s<double>::type;

  Eigen::Matrix<double, N, 1> a=Eigen::Matrix<double, N, 1>::Random(N);

  Eigen::Matrix<double, N, N> A_d=/*a.asDiagonal();/*/Eigen::Matrix<double, N, N>::Random(N,N);
  Eigen::Matrix<adouble, N, N> A_ad;
  Eigen::Matrix<adouble_t, N, N> A_adt;
  Eigen::Matrix<DCO_T, N, N> A_dco;


  Eigen::Matrix<double, N, 1> b_d=Eigen::Matrix<double, N, 1>::Random(N);
  Eigen::Matrix<adouble, N, 1> b_ad;
  Eigen::Matrix<adouble_t, N, 1> b_adt;
  Eigen::Matrix<DCO_T, N, 1> b_dco;

  Eigen::Matrix<double, N, 1> x_d_LR,x_d_QR;
  Eigen::Matrix<adouble, N, 1> x_ad_LR,x_ad_QR;
  Eigen::Matrix<adouble_t, N, 1> x_adt_LR,x_adt_QR;
  Eigen::Matrix<DCO_T, N, 1> x_dco_LR,x_dco_QR;

  for(auto i = 0; i<N; i++) {
      b_ad(i)=b_d(i);
      b_adt(i)=b_d(i);
      dco::value(b_dco(i))=b_d(i);
      for(auto j=0; j<N; j++){
          A_ad(i,j)=A_d(i,j);
          A_adt(i,j)=A_d(i,j);
          dco::value(A_dco(i,j))=A_d(i,j);
      }
  }

  Eigen::PartialPivLU<Eigen::Matrix<double, N, N>> LR_d(A_d);
  Eigen::PartialPivLU<Eigen::Matrix<adouble, N, N>> LR_ad(A_ad);
  Eigen::PartialPivLU<Eigen::Matrix<adouble_t, N, N>> LR_adt(A_adt);
  Eigen::PartialPivLU<Eigen::Matrix<DCO_T, N, N>> LR_dco(A_dco);

  x_d_LR=LR_d.solve(b_d);
  x_ad_LR=LR_ad.solve(b_ad);
  x_adt_LR=LR_adt.solve(b_adt);
  x_dco_LR=LR_dco.solve(b_dco);

  double error_d_LR = (A_d*x_d_LR-b_d).norm()/b_d.norm();
  adouble error_ad_LR = (A_ad*x_ad_LR-b_ad).norm()/b_ad.norm();
  adouble_t error_adt_LR = (A_adt*x_adt_LR-b_adt).norm()/b_adt.norm();
  DCO_T error_dco_LR = (A_dco*x_dco_LR-b_dco).norm()/b_dco.norm();

  std::cout<<"x_d_LR^T= "<<x_d_LR.transpose()<<std::endl;
  std::cout<<"error_d_LR= "<<error_d_LR<<std::endl<<std::endl;

  std::cout<<"x_ad_LR^T= ";
  for(auto i = 0; i < N; i++){
      std::cout<<x_ad_LR(i).getValue()<<" ";
  }
  std::cout<<std::endl<<"error_ad_LR= "<<error_ad_LR<<std::endl<<std::endl;

  std::cout<<"x_adt_LR^T= ";
  for(auto i = 0; i < N; i++){
      std::cout<<x_adt_LR(i).getValue()<<" ";
  }
  std::cout<<std::endl<<"error_adt_LR= "<<error_adt_LR<<std::endl<<std::endl;

  std::cout<<"x_dco_LR^T= "<<x_dco_LR.transpose()<<std::endl;
  std::cout<<"error_dco_LR= "<<error_dco_LR<<std::endl<<std::endl;



  Eigen::HouseholderQR<Eigen::Matrix<double, N, N>> QR_d(A_d);
  //Eigen::HouseholderQR<Eigen::Matrix<adouble, N, N>> QR_ad(A_ad);
  Eigen::HouseholderQR<Eigen::Matrix<adouble_t, N, N>> QR_adt(A_adt);
  Eigen::HouseholderQR<Eigen::Matrix<DCO_T, N, N>> QR_dco(A_dco);

  x_d_QR=QR_d.solve(b_d);
  //x_ad_QR=QR_ad.solve(b_ad);
  x_adt_QR=QR_adt.solve(b_adt);
  x_dco_QR=QR_dco.solve(b_dco);

  double error_d_QR = (A_d*x_d_QR-b_d).norm()/b_d.norm();
  //adouble error_ad_QR = (A_ad*x_ad_QR-b_ad).norm()/b_ad.norm();
  adouble_t error_adt_QR = (A_adt*x_adt_QR-b_adt).norm()/b_adt.norm();
  DCO_T error_dco_QR = (A_dco*x_dco_QR-b_dco).norm()/b_dco.norm();

  std::cout<<"x_d_QR^T= "<<x_d_QR.transpose()<<std::endl;
  std::cout<<"error_d_QR= "<<error_d_QR<<std::endl<<std::endl;

  /*std::cout<<"x_ad_QR^T= ";
  for(auto i = 0; i < N; i++){
      std::cout<<x_ad_QR(i).getValue()<<" ";
  }
  std::cout<<std::endl<<"error_ad_QR= "<<error_ad_QR<<std::endl<<std::endl;*/

  std::cout<<"x_adt_QR^T= ";
  for(auto i = 0; i < N; i++){
      std::cout<<x_adt_QR(i).getValue()<<" ";
  }
  std::cout<<std::endl<<"error_adt_QR= "<<error_adt_QR<<std::endl<<std::endl;

  std::cout<<"x_dco_QR^T= "<<x_dco_QR.transpose()<<std::endl;
  std::cout<<"error_dco_QR= "<<error_dco_QR<<std::endl<<std::endl;

  return 0;
}
