
#include<iostream>
#include<adolc/adolc.h>


template<typename T,typename TP>
T f(T x, TP p) {
    return x*x*p;
}

//template<typename T>
void create_tape() {
    adouble x,y,p;
    double *xp=new double,*yp=new double,*pp=new double;
    trace_on(0);
    x<<=*xp;
    p<<=*pp;
    y=f(x,p);
    y>>=*yp;
    trace_off();
    delete xp;
    delete yp;
}
template<typename TT>
void do_something(TT &x,TT& p){
    using T=double;
    T *xp=new T[2],*yp=new T;
    T** der=new T*;
    *der=new T;
    *xp=x;//.value();
    xp[1]=p;//.value();
    function(0,1,2,xp,yp);
    jacobian(0,1,2,xp,der);
    std::cout<<"f("<<*xp<<")= "<<*yp<<" ; f'("<<*xp<<")= "<<**der<<std::endl;
    x=x-**der;
    std::cout<<"x_new= "<<x<<std::endl;
    delete xp;
    delete yp;
    delete *der;
    delete der;
}
void create_tape2() {
    adouble x,p;
    double *xp=new double,*pp=new double;
    trace_on(1);
    x=*xp;
    p<<=*pp;
    //do_something(x,p);
    x>>=*xp;
    trace_off();
    delete xp;
    delete pp;
}

int main() {
  double x=10;
  double p=2;
  double *xp =new double;
  double *pp =new double;
  double** der=new double*;
  *der=new double;
  *pp=p;
  *xp=x;
  create_tape();
  do_something(x,p);
  /*create_tape2();
  function(1,1,1,pp,xp);
  jacobian(1,1,1,pp,der);*/
  delete *der;
  delete der;
  delete xp;
  delete pp;

  return 0;
}
