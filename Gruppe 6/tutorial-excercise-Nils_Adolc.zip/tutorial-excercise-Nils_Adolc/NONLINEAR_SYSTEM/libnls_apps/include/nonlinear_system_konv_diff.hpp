#pragma once

#include "nonlinear_system.hpp"
#include "parameters.hpp"

namespace Konv_Diff{

const int NS=Parameters::NS;
const int NP=Parameters::NP;

template<typename TS, typename TP=TS>
class System : public Nonlinear::System<TS,TP,NS,NP> {
  using Nonlinear::System<TS,TP,NS,NP>::_x;
  using Nonlinear::System<TS,TP,NS,NP>::_p;
public:
  System();
  typename Nonlinear::System<TS,TP,NS,NP>::VTS f();
  typename Nonlinear::System<TS,TP,NS,NP>::MTS dfdx();
};

}

#include "../src/nonlinear_system_konv_diff.cpp"
