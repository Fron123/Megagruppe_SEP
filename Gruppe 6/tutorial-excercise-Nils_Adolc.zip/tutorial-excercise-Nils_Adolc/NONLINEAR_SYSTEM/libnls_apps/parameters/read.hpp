#include<fstream>

template<typename T,int N>
Eigen::Matrix<T,N,1> readfiletovec(std::string file){
    Eigen::Matrix<T,N,1> vec;

    std::ifstream read(file);

    for(auto i=0; i < N;i++)read>>vec(i);

    read.close();

    return vec;
}
