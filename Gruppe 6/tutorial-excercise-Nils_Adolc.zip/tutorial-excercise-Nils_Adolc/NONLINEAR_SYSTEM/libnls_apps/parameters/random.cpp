
#include<iostream>
#include<fstream>

#include<Eigen/Dense>

#include "parameters.hpp"

template<typename T,int N>
void writevectofile(typename Eigen::Matrix<T,N,1> vec,std::string file){

    std::ofstream write(file);

    for(auto i=0; i < N;i++)write<<vec(i)<<" ";

    write.close();

}

int main() {

  using T=double;

  Eigen::Matrix<T,Parameters::NP,1> p=Eigen::Matrix<T,Parameters::NP,1>::Random(Parameters::NP);
  Eigen::Matrix<T,Parameters::NS,1> x=Eigen::Matrix<T,Parameters::NS,1>::Random(Parameters::NS);

  std::cout<<"x^T= "<<x.transpose()<<std::endl;
  std::cout<<"p^T= "<<p.transpose()<<std::endl<<std::endl;;

  writevectofile<T,Parameters::NP>(p,Parameters::file_p);
  writevectofile<T,Parameters::NS>(x,Parameters::file_x);

  return 0;

}
