//parameters
namespace Parameters {

const int NS=20;

const int NP=20;

std::string file_p="../parameters/p.txt";

std::string file_x="../parameters/x.txt";

double eps=1e-6;

}

