#include<adolc/adolc.h>

namespace Konv_Diff {
template<typename TS, typename TP>
System<TS,TP>::System() : Nonlinear::System<TS,TP,NS,NP>(NS,NP) {}

#include "konv_diff.hpp"


template<typename TS, typename TP>
typename Nonlinear::System<TS,TP,NS,NP>::VTS
System<TS,TP>::f() {    return F<TS,TP>(_x,_p); }

template<typename TS, typename TP>
typename Nonlinear::System<TS,TP,NS,NP>::MTS
System<TS,TP>::dfdx() { 
  typename Nonlinear::System<TS,TP,NS,NP>::MTS drdx(NS,NS);
  typename Nonlinear::System<adouble,adouble,NS,NP>::VTS x_t,r_t;
  typename Nonlinear::System<adouble,adouble,NS,NP>::VTP p_t;
  double*x_s=new double[NS+NP];
  double r_s;
  double**der=new double*[NS];
  for (auto i=0; i < NS; i++){
    der[i]=new double[NS+NP];
    x_s[i]=_x(i);
  }
  for (auto i=0; i < NP; i++){
    x_s[NS+i]=_p(i);
  }
  trace_on(0);
  for (auto i=0;i<NS;i++){
    x_t(i)<<=x_s[i];
  }
  for (auto i=0; i < NP; i++){
    p_t(i)<<=x_s[NS+i];
  }
  r_t=F<adouble,adouble>(x_t,p_t);
  for(auto i=0; i < NS; i++){
      r_t(i)>>=r_s;
  }
  trace_off();
  jacobian(0,NS,NS+NP,x_s,der);

  for (auto i=0;i<NS;i++) {
    for (auto j=0;j<NS;j++) {
      drdx(i,j)=der[i][j];
    }
    delete [] der[i];
  }
  delete [] x_s;
  delete [] der;
  return drdx;
}

}
