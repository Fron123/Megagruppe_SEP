#include<adolc/adolc.h>

namespace LV_mult_pred_adolc {


template<typename TS, typename TP>
System<TS,TP>::System() : Nonlinear::System<TS,TP,NS,NP>(NS,NP) {}

#include "lv_mult_pred.hpp"

double**S;


template<typename TS, typename TP>
typename Nonlinear::System<TS,TP,NS,NP>::VTS
System<TS,TP>::f() {    return F<TS,TP>(_x,_p); }


template<typename TS, typename TP>
typename Nonlinear::System<TS,TP,NS,NP>::MTS
System<TS,TP>::dfdx() { 

  typename Nonlinear::System<TS,TP,NS,NP>::MTS drdx(NS,NS);

  typename Nonlinear::System<adouble,adouble,NS,NP>::VTS x_t,r_t;
  typename Nonlinear::System<adouble,adouble,NS,NP>::VTP p_t;

  double*x_s=new double[NS+NP];
  double r_s;

  int size=(NS+NP+2)*(NS+NP+1)/2;
  double temp_sum;
  double * temp_hess= new double[NS];
  double *seed=new double[NP];
  double**tensor=new double*[NS];

  for (auto i=0; i < NS; i++){
    tensor[i]=new double[size];
    x_s[i]=_x(i).getValue();
  }
  for (auto i=0; i < NP; i++){
    x_s[NS+i]=_p(i).getValue();
  }

  trace_on(0);
  for (auto i=0;i<NS;i++){
    x_t(i)<<=x_s[i];
  }
  for (auto i=0; i < NP; i++){
    p_t(i)<<=x_s[NS+i];
  }
  r_t=F<adouble,adouble>(x_t,p_t);
  for(auto i=0; i < NS; i++){
      r_t(i)>>=r_s;
  }

  trace_off();

  tensor_eval(0,NS,NS+NP,2,NS+NP,x_s,tensor,S);

  for (auto i=0;i<NS;i++) {
    for (auto j=0;j<NS;j++) {
      drdx(i,j)=tensor[i][(j+1)*(j+2)/2];
      for(auto k=0;k<NS;k++){
          if(k<=j)temp_hess[k]=tensor[i][(j+1)*(j+2)/2+k+1];
          else temp_hess[k]=tensor[i][(k+1)*(k+2)/2+j+1];
      }
      for(auto k=0; k < NP; k++){
          temp_sum=tensor[i][(k+NS+1)*(k+NS+2)/2+j+1];
          for(auto l=0;l<NS;l++){
              temp_sum+=_x(l).getADValue()[k]*temp_hess[l];
          }
          seed[k]=temp_sum;
      }

      drdx(i,j).setADValue(seed);

    }

    delete [] tensor[i];
  }


  delete [] x_s;
  delete [] tensor;
  delete [] seed;
  delete [] temp_hess;

  return drdx;
}

}
