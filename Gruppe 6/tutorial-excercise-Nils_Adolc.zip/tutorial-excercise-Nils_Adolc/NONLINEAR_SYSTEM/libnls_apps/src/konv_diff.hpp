template<typename TS, typename TP>
static inline typename Nonlinear::System<TS,TP,NS,NP>::VTS
F(const typename Nonlinear::System<TS,TP,NS,NP>::VTS& x, const typename Nonlinear::System<TS,TP,NS,NP>::VTP& p) {

  int nx=x.size();
  int np = p.size();

  typename Nonlinear::System<TS,TP,NS,NP>::VTS r(nx);

  TP * p_sum=new TP[5];
  for(auto i=0;i<4;i++)p_sum[i]=0;
  for(auto i=0;i<np;i++)p_sum[i%4]+=p(i);

  r(0)=p_sum[0]*nx*nx*(p[2]-2*x(0)+x(1))+p_sum[1]*nx*(x(1)-p_sum[2]);

  for(auto i=1;i<nx-1;i++){
      r(i)=p_sum[0]*nx*nx*(x(i-1)-2*x(i)+x(i+1))+p_sum[1]*nx*(x(i+1)-x(i-1));
  }

  r(nx-1)=p_sum[0]*nx*nx*(x(nx-2)-2*x(nx-1)+p_sum[3])+p_sum[1]*nx*(p_sum[3]-x(nx-2));

  delete [] p_sum;

  return r;
}
