#include "dco.hpp"

namespace Konv_Diff_dco {
template<typename TS, typename TP>
System<TS,TP>::System() : Nonlinear::System<TS,TP,NS,NP>(NS,NP) {}

#include "konv_diff.hpp"

template<typename TS, typename TP>
typename Nonlinear::System<TS,TP,NS,NP>::VTS
System<TS,TP>::f() {    return F<TS,TP>(_x,_p); }

template<typename TS, typename TP>
typename Nonlinear::System<TS,TP,NS,NP>::MTS
System<TS,TP>::dfdx() { 
    auto s=_x.size();
    typename Nonlinear::System<TS,TP,NS,NP>::MTS drdx(s,s);
    using DCO_T=typename dco::gt1s<TS>::type;
    typename Nonlinear::System<DCO_T,TP,NS,NP>::VTS x_t(s), r_t(s);
    for (auto i=0;i<s;i++) dco::value(x_t(i))=_x(i);
    for (auto i=0;i<s;i++) {
      dco::derivative(x_t(i))=1;
      r_t=F<DCO_T,TP>(x_t,_p);
      for (auto j=0;j<s;j++) drdx(j,i)=dco::derivative(r_t(j));
      dco::derivative(x_t(i))=0;
    }
    //std::cout<<dco::derivative(_x(0))<<std::endl;
    return drdx;
}

}
