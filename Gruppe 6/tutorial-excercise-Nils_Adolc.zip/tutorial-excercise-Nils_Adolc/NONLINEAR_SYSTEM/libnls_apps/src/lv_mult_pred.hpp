template<typename TS, typename TP>
static inline typename Nonlinear::System<TS,TP,NS,NP>::VTS
F(const typename Nonlinear::System<TS,TP,NS,NP>::VTS& x, const typename Nonlinear::System<TS,TP,NS,NP>::VTP& p) {

  int nx=x.size();
  int np = p.size();

  typename Nonlinear::System<TS,TP,NS,NP>::VTS r(nx);

  r(0)=p(0)*p(0)*x(0)*(1-x(0));
  for(auto j=1;j<nx;j++)r(0)-=p(j%np)*p(j%np)*x(0)*x(j);

  for(auto i=1;i<nx;i++){
      r(i)=p((nx+i)%np)*p((nx+i)%np)*x(i)*x(0)-p((2*nx+i)%np)*p((2*nx+i)%np)*x(i);
  }
  return r;
}
