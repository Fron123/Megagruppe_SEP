
#include<iostream>
#include<chrono>

#include "nonlinear_system_konv_diff_dco.hpp"
#include "linear_solver_qr.hpp"
#include "nonlinear_solver_newton.hpp"
#include "read.hpp"

int main() {

  auto t_start=std::chrono::high_resolution_clock::now();

  using T=double;

  Konv_Diff_dco::System<T,T> nlsys;
  Linear::Solver_QR<T,Konv_Diff_dco::NS> lsol;
  Nonlinear::Solver_Newton<T,T,Konv_Diff_dco::NS,Konv_Diff_dco::NP> nlsol(lsol,Parameters::eps);

  //nlsys.p()=Nonlinear::System<T,T,Konv_Diff_dco::NS,Konv_Diff_dco::NP>::VTP::Random(nlsys.np());
  //nlsys.x()=Nonlinear::System<T,T,Konv_Diff_dco::NS,Konv_Diff_dco::NP>::VTS::Random(nlsys.ns());
  nlsys.p()=readfiletovec<T,Konv_Diff_dco::NP>(Parameters::file_p);
  nlsys.x()=readfiletovec<T,Konv_Diff_dco::NS>(Parameters::file_x);


  //std::cout << "x^T=" << nlsys.x().transpose() << std::endl;
  //std::cout << "p^T=" << nlsys.p().transpose() << std::endl;
  //std::cout << "f(x)^T=" << nlsys.f().transpose() << std::endl;

  nlsol.solve(nlsys);

  std::cout << "x^T=" << nlsys.x().transpose() << std::endl;
  std::cout << "||f(x)||=" << nlsys.f().norm() << std::endl;

  auto t_end=std::chrono::high_resolution_clock::now();
  auto runtime=std::chrono::duration_cast<std::chrono::microseconds>(t_end-t_start);
  std::cout<<"runtime: "<<runtime.count()<<std::endl<<std::endl;

  return 0;

}
