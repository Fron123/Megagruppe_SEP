
#include<iostream>
#include<chrono>

#include "dco.hpp"

#include "nonlinear_system_konv_diff_dco.hpp"
#include "linear_solver_qr.hpp"
#include "nonlinear_solver_newton.hpp"
#include "read.hpp"



int main() {

  auto t_start=std::chrono::high_resolution_clock::now();

  using T=double;
  using DCO_TT=typename dco::gt1s<T>::type;

  Konv_Diff_dco::System<DCO_TT,DCO_TT> nlsys;
  Linear::Solver_QR<DCO_TT,Konv_Diff_dco::NS> lsol;
  Nonlinear::Solver_Newton<DCO_TT,DCO_TT,Konv_Diff_dco::NS,Konv_Diff_dco::NP> nlsol(lsol,Parameters::eps);

  typename Nonlinear::System<T,T,Konv_Diff_dco::NS,Konv_Diff_dco::NP>::VTP p_rand;//=Nonlinear::System<T,T,Konv_Diff_dco::NS,Konv_Diff_dco::NP>::VTP::Random(nlsys.np());
  typename Nonlinear::System<T,T,Konv_Diff_dco::NS,Konv_Diff_dco::NP>::VTS x_rand;//=Nonlinear::System<T,T,Konv_Diff_dco::NS,Konv_Diff_dco::NP>::VTS::Random(nlsys.ns());
  p_rand=readfiletovec<T,Konv_Diff_dco::NP>(Parameters::file_p);
  x_rand=readfiletovec<T,Konv_Diff_dco::NS>(Parameters::file_x);

  Eigen::Matrix<T,Konv_Diff_dco::NS,Konv_Diff_dco::NP> dxdp;


  //std::cout << "x^T=" << x_rand.transpose() << std::endl;
  //std::cout << "p^T=" << p_rand.transpose() << std::endl;
  //std::cout << "f(x)^T=" << Konv_Diff_dco::F<T,T>(x_rand,p_rand).transpose() << std::endl;

  for (auto j=0;j<Konv_Diff_dco::NP;j++) dco::value(nlsys.p()(j))=p_rand(j);

  for (auto i=0;i<Konv_Diff_dco::NP;i++) {
    for (auto j=0;j<Konv_Diff_dco::NS;j++){
        dco::value(nlsys.x()(j))=x_rand(j);
        dco::derivative(nlsys.x()(j))=0;
    }
    dco::derivative(nlsys.p()(i))=1;
    nlsol.solve(nlsys);
    for (auto j=0;j<Konv_Diff_dco::NS;j++) dxdp(j,i)=dco::derivative(nlsys.x()(j));
    dco::derivative(nlsys.p()(i))=0;
  }

  std::cout << "x^T=" << nlsys.x().transpose() << std::endl;
  std::cout << "||f(x)||=" << nlsys.f().norm() << std::endl;
  std::cout << "dxdp=" <<std::endl<< dxdp << std::endl;

  auto t_end=std::chrono::high_resolution_clock::now();
  auto runtime=std::chrono::duration_cast<std::chrono::microseconds>(t_end-t_start);
  std::cout<<"runtime: "<<runtime.count()<<std::endl<<std::endl;

  return 0;

}
