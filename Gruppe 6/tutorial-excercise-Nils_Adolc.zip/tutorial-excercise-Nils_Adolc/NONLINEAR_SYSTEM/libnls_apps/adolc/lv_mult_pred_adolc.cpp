
#include<iostream>
#include<chrono>

#include <adolc/adtl.h>

#include "nonlinear_system_lv_mult_pred_adolc.hpp"
#include "linear_solver_qr.hpp"
#include "nonlinear_solver_newton.hpp"
#include "read.hpp"


typedef adtl::adouble adouble_t;


int main() {

  auto t_start=std::chrono::high_resolution_clock::now();

  adtl::setNumDir(LV_mult_pred_adolc::NP);

  using T=double;

  LV_mult_pred_adolc::System<adouble_t,adouble_t> nlsys;
  Linear::Solver_QR<adouble_t,LV_mult_pred_adolc::NS> lsol;
  Nonlinear::Solver_Newton<adouble_t,adouble_t,LV_mult_pred_adolc::NS,LV_mult_pred_adolc::NP> nlsol(lsol,Parameters::eps);

  typename Nonlinear::System<T,T,LV_mult_pred_adolc::NS,LV_mult_pred_adolc::NP>::VTS x_res, x_rand;//=Nonlinear::System<T,T,LV_mult_pred_adolc::NS,LV_mult_pred_adolc::NP>::VTS::Random(nlsys.ns());
  typename Nonlinear::System<T,T,LV_mult_pred_adolc::NS,LV_mult_pred_adolc::NP>::VTP p_rand;//=Nonlinear::System<T,T,LV_mult_pred_adolc::NS,LV_mult_pred_adolc::NP>::VTP::Random(nlsys.np());
  p_rand=readfiletovec<T,LV_mult_pred_adolc::NP>(Parameters::file_p);
  x_rand=readfiletovec<T,LV_mult_pred_adolc::NS>(Parameters::file_x);

  T * seed = new T [LV_mult_pred_adolc::NP];
  LV_mult_pred_adolc::S=new T*[LV_mult_pred_adolc::NS+LV_mult_pred_adolc::NP];

  Eigen::Matrix<T,LV_mult_pred_adolc::NS,LV_mult_pred_adolc::NP> dxdp;

  //std::cout << "x^T=" << x_rand.transpose() << std::endl;
  //std::cout << "p^T=" << p_rand.transpose() << std::endl;
  //std::cout << "f(x)^T=" << LV_mult_pred_adolc::F<T,T>(x_rand,p_rand).transpose() << std::endl;

  for(auto i = 0;i<LV_mult_pred_adolc::NS;i++){
      nlsys.x()(i)=x_rand(i);

      LV_mult_pred_adolc::S[i]=new T [LV_mult_pred_adolc::NS+LV_mult_pred_adolc::NP];
      for(auto j=0;j<LV_mult_pred_adolc::NS+LV_mult_pred_adolc::NP;j++){
          if(j==i)LV_mult_pred_adolc::S[i][j]=1;
          else LV_mult_pred_adolc::S[i][j]=0;
      }
  }

  for(auto i = 0;i<LV_mult_pred_adolc::NP;i++){
      nlsys.p()(i)=p_rand(i);

      seed[i]=0;

      LV_mult_pred_adolc::S[LV_mult_pred_adolc::NS+i]=new double [LV_mult_pred_adolc::NS+LV_mult_pred_adolc::NP];
      for(auto j=0;j<LV_mult_pred_adolc::NS+LV_mult_pred_adolc::NP;j++){
          if(j==LV_mult_pred_adolc::NS+i)LV_mult_pred_adolc::S[LV_mult_pred_adolc::NS+i][j]=1;
          else LV_mult_pred_adolc::S[LV_mult_pred_adolc::NS+i][j]=0;
      }
  }

  for(auto i = 0;i<LV_mult_pred_adolc::NP;i++){
      seed[i]=1;
      nlsys.p()(i).setADValue(seed);
      seed[i]=0;
  }

  nlsol.solve(nlsys);

  for(auto i=0;i<LV_mult_pred_adolc::NS;i++){
      x_res(i)=nlsys.x()(i).getValue();
      const double * temp=nlsys.x()(i).getADValue();
      for(auto j=0;j<LV_mult_pred_adolc::NP;j++){
          dxdp(i,j)=temp[j];
      }
  }

  std::cout << "x^T=" << x_res.transpose() << std::endl;
  std::cout << "||f(x)||=" << nlsys.f().norm().getValue()<< std::endl;
  std::cout << "dxdp=" <<std::endl<< dxdp << std::endl;

  for(auto i = 0; i<LV_mult_pred_adolc::NS+LV_mult_pred_adolc::NP; i++){
      delete [] LV_mult_pred_adolc::S[i];
  }
  delete [] LV_mult_pred_adolc::S;
  delete [] seed;

  auto t_end=std::chrono::high_resolution_clock::now();
  auto runtime=std::chrono::duration_cast<std::chrono::microseconds>(t_end-t_start);
  std::cout<<"runtime: "<<runtime.count()<<std::endl<<std::endl;

  return 0;

}
