
#include<iostream>
#include<chrono>

#include "nonlinear_system_lv_mult_pred.hpp"
#include "linear_solver_qr.hpp"
#include "nonlinear_solver_newton.hpp"
#include "read.hpp"


int main() {

  auto t_start=std::chrono::high_resolution_clock::now();

  using T=double;

  LV_mult_pred::System<T,T> nlsys;
  Linear::Solver_QR<T,LV_mult_pred::NS> lsol;
  Nonlinear::Solver_Newton<T,T,LV_mult_pred::NS,LV_mult_pred::NP> nlsol(lsol,Parameters::eps);

  //nlsys.p()=Nonlinear::System<T,T,LV_mult_pred::NS,LV_mult_pred::NP>::VTP::Random(nlsys.np());
  //nlsys.x()=Nonlinear::System<T,T,LV_mult_pred::NS,LV_mult_pred::NP>::VTS::Random(nlsys.ns());
  nlsys.p()=readfiletovec<T,LV_mult_pred::NP>(Parameters::file_p);
  nlsys.x()=readfiletovec<T,LV_mult_pred::NS>(Parameters::file_x);

  //std::cout << "x^T=" << nlsys.x().transpose() << std::endl;
  //std::cout << "p^T=" << nlsys.p().transpose() << std::endl;
  //std::cout << "f(x)^T=" << nlsys.f().transpose() << std::endl;

  nlsol.solve(nlsys);

  std::cout << "x^T=" << nlsys.x().transpose() << std::endl;
  std::cout << "||f(x)||=" << nlsys.f().norm() << std::endl;

  auto t_end=std::chrono::high_resolution_clock::now();
  auto runtime=std::chrono::duration_cast<std::chrono::microseconds>(t_end-t_start);
  std::cout<<"runtime: "<<runtime.count()<<std::endl<<std::endl;

  return 0;

}
