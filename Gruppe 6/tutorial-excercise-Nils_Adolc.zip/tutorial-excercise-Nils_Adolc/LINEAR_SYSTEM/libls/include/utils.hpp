// naumann@stce.rwth-aachen.de

#pragma once

namespace Utils {

  const int Dynamic=Eigen::Dynamic;

}
