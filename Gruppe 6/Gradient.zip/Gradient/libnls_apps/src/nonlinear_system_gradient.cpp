#include <adolc/adolc.h>

namespace Convex{

template<typename TS, typename TP,int NS, int NP>
System<TS,TP,NS,NP>::System() : Nonlinear::System<TS,TP,NS,NP>(NS,NP) {}

template<typename TS, typename TP,int NS, int NP>
typename Nonlinear::System<TS,TP,NS,NP>::VTS& 
System<TS,TP,NS,NP>::f() {
  typename Nonlinear::System<TS,TP,NS,NP>::VTS r;
  r(0)=_x(0)*_x(0)-_p(0); 
  return r;
}
/*
template<typename TS, typename TP>
typename Nonlinear::System<TS,TP,NS,NP>::MTS&
System<TS,TP>::drdx(System<TS,TP> nlsys) {
  typename Nonlinear::System<TS,TP,NS,NP>::MTS drdx;		//Gradient muss noch mit Adolc berechnet werden
  drdx= gradient(; ////
  return drdx;
} 
*/
}
