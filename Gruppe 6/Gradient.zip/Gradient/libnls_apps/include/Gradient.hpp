#pragma once

#include "nonlinear_system.hpp"

namespace Convex{


template<typename TS, typename TP,int NS, int NP>
class System : public Nonlinear::System<TS,TP,1,1>
{
  using Nonlinear::System<TS,TP,NS,NP>::_x;
  using Nonlinear::System<TS,TP,NS,NP>::_p;
public:
  System();
  typename Nonlinear::System<TS,TP,NS,NP>::VTS x_1;
  typename Nonlinear::System<TS,TP,NS,NP>::VTS x_2;
  typename Nonlinear::System<TS,TP,NS,NP>::VTS grad_1;
  typename Nonlinear::System<TS,TP,NS,NP>::VTS grad_2;
  typename Nonlinear::System<TS,TP,NS,NP>::VTS f();
  typename Nonlinear::System<TS,TP,NS,NP>::MTS drdx(System<TS,TP,NS,NP>);
};
}
#include "../src/nonlinear_system_gradient.cpp"
