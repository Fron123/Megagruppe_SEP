#pragma once
#include<Eigen/Dense>
#include "nonlinear_system.hpp"
#include "nonlinear_system_toy.hpp"

namespace Nonlinear{

template<typename TS, typename TP, int NS, int NP>
class Linesearch{
//  using VTS=Eigen::Matrix<TS,NS,1>;
public:
  using VTS=Eigen::Matrix<TS,NS,1>;

  TS v0;
  TS x_prev;
  TS eps;
  TS iteration(Toy::System<TS,TP> nlsys);
 bool checkpdHessian();
  TS getv0();
  TS getx_prev();		

  };
}  
