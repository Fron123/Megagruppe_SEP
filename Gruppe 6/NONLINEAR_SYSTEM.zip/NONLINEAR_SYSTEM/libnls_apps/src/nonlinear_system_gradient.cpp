#include <adolc/adolc.h>

namespace Convex{

template<typename TS, typename TP>
System<TS,TP>::System() : Nonlinear::System<TS,TP,NS,NP>(NS,NP) {}

template<typename TS, typename TP>
typename Nonlinear::System<TS,TP,NS,NP>::VTS 
System<TS,TP>::f() {
  typename Nonlinear::System<TS,TP,NS,NP>::VTS r;
  r(0)=_x(0)*_x(0)-_p(0); 
  return r;
}

template<typename TS, typename TP>
typename Nonlinear::System<TS,TP,NS,NP>::MTS 
System<TS,TP>::dfdx() {
  typename Nonlinear::System<TS,TP,NS,NP>::MTS drdx;
  drdx(0,0)=2*_x(0);
  return drdx;
} 
/*
template<typename TS, typename TP,int NS, int NP>
typename Nonlinear::System<TS,TP,NS,NP>::VTS 
System<TS,TP>::gradient(int NS, typename Nonlinear::System<TS,TP,NS,NP>::VTS x) {
  typename Nonlinear::System<TS,TP,NS,NP>::VTS gradient;
  gradient(int NS,VTS x,VTS gradient); 
  return gradient;
}

/*
template<typename TS, typename TP>
typename Nonlinear::System<TS,TP,NS,NP>::MTS&
System<TS,TP>::drdx(System<TS,TP> nlsys) {
  typename Nonlinear::System<TS,TP,NS,NP>::MTS drdx;		//Gradient muss noch mit Adolc berechnet werden
  drdx= gradient(; ////
  return drdx;
} 
*/
}
