#include<iostream>
#include<adolc/adolc.h>
#include "Gradient.hpp"
#include "linear_solver_qr.hpp"
#include "nonlinear_solver_newton.hpp"
#include <adolc/adouble.h>

int main() {
  using T= double;
  const int NS=1;
  const int NP=1;
  const double* vec;
  double* gra;
  Convex::System<T,T> nlsys;
  Linear::Solver_QR<T,NS> lsol;
  Nonlinear::Solver_Newton<T,T,NS,NP> nlsol(lsol,1e-7);
  nlsys.x()(0)=1;
  nlsys.p()(0)=2;
  nlsol.solve(nlsys);
  T eps= 1e-8;
  T alpha = 0.1;

  vec = &nlsys.x().cast<const double> ();


  gradient(1,NS,vec,gra);
/* nlsys.x_1 = nlsys.x();
  nlsys.grad_1 = nlsys.drdx(nlsys);
  
  while(grad_2.norm() >= eps){

    nlsys.x() = x_1;
    grad_1 = drdx(nlsys);
    x_2 = x_1 - alpha * grad_1; 
    nlsys.x() = x_2;
    grad_2 = drdx(nlsys);
    alpha = (((x_2 - x_1).transpose()) * (grad_2 - grad_1)).norm() / ((grad_2 - grad_1).squaredNorm());
}

 */ 
  std::cout << "x=" << nlsys.x() << std::endl;
  //std::cout << "gradient: " << nlsys.drdx(nlsys) << std::endl;
  return 0;
}
