#pragma once

#include "nonlinear_system.hpp"

namespace Nonlinear {

template<typename TS, typename TP, int NS, int NP>
class Stepsize_control {
  double shrinking_factor;
  double alpha;
  double c1;
  double c2;
  //enum condition {1, 2, 3}; //1= Armijo; 2=Curvature; 3=Wolfe  
  //condition cond;

public:
  Stepsize_control(double, double, double, double);
  double sca(System<TS,TP,NS,NP>&);
  //virtual void solve(System<TS,TP,NS,NP>&)=0;
};

}
#include "../src/stepsize_control.cpp"

