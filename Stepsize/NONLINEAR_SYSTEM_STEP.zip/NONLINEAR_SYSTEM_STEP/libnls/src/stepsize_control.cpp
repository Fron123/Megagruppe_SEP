namespace Nonlinear {

//template<typename TS, typename TP, int NS, int NP>
//Solver_Newton<TS,TP,NS,NP>::Solver_Newton(Linear::Solver<TS,NS>& lsol, const TS& eps) : _lsol(lsol), _eps(eps) {}

template<typename TS, typename TP, int NS, int NP>
Stepsize_control<TS,TP,NS,NP>::Stepsize_control(double shrinking_factor, double alpha, double c1, double c2) : shrinking_factor(shrinking_factor), alpha(alpha), c1(c1), c2(c2) {}

template<typename TS, typename TP, int NS, int NP>
double
Stepsize_control<TS,TP,NS,NP>::sca(System<TS,TP,NS,NP>& nlsys) {

 alpha=100.0;
 typename Nonlinear::System<TS,TP,NS,NP>::VTS x_initial = nlsys.x();
 typename Nonlinear::System<TS,TP,NS,NP>::VTS prev;
 typename Nonlinear::System<TS,TP,NS,NP>::VTS cur; 
 typename Nonlinear::System<TS,TP,NS,NP>::VTS grad;

 typename Nonlinear::System<TS,TP,NS,NP>::VTS temp;

// temp=x_initial+alpha*d


int i=0;
 while (i<10) {
    	
	alpha=shrinking_factor*alpha;
	i=i+1;
  }

return alpha;
}

}

